"""
NexusOS v2 - Core Database Layer

Replaces JSON file storage with SQLite for:
- Users
- Conversations
- Memory (episodic, semantic, working)
- Events
- Audit logs
- Skills
"""

import sqlite3
import json
import hashlib
import secrets
import os
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from contextlib import contextmanager
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

DB_PATH = os.environ.get("NEXUSOS_DB", "/opt/nexusos-data/nexusos.db")


class Database:
    """SQLite database for NexusOS."""
    
    def __init__(self, db_path: str = None):
        self.db_path = db_path or DB_PATH
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()
    
    @contextmanager
    def _get_conn(self):
        """Get database connection."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
    
    def _init_db(self):
        """Initialize database schema."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            
            # Users table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    email TEXT UNIQUE,
                    password_hash TEXT,
                    name TEXT,
                    role TEXT DEFAULT 'user',
                    subscription TEXT DEFAULT 'free',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_login TEXT,
                    api_keys TEXT,
                    preferences TEXT,
                    active_model TEXT DEFAULT 'ollama'
                )
            """)
            
            # Conversations table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    title TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    message_count INTEGER DEFAULT 0,
                    metadata TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Messages table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    conversation_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    model_used TEXT,
                    directive TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    metadata TEXT,
                    FOREIGN KEY (conversation_id) REFERENCES conversations(id)
                )
            """)
            
            # Memory: Working (short-term)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS memory_working (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value TEXT,
                    expires_at TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Memory: Episodic (long-term events)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS memory_episodic (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    event_type TEXT,
                    summary TEXT,
                    details TEXT,
                    importance REAL DEFAULT 0.5,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Memory: Semantic (learned knowledge)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS memory_semantic (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    entity_type TEXT,
                    entity_name TEXT,
                    embedding_id TEXT,
                    knowledge TEXT,
                    confidence REAL DEFAULT 0.5,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Patterns (learned patterns)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    pattern_type TEXT,
                    pattern_data TEXT,
                    success_count INTEGER DEFAULT 0,
                    failure_count INTEGER DEFAULT 0,
                    last_used TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Skills
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS skills (
                    id TEXT PRIMARY KEY,
                    user_id TEXT,
                    name TEXT NOT NULL,
                    description TEXT,
                    code TEXT,
                    triggers TEXT,
                    actions TEXT,
                    is_public INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Agents (multi-agent support)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS agents (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    role TEXT,
                    personality TEXT,
                    tools TEXT,
                    memory_id TEXT,
                    status TEXT DEFAULT 'idle',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_active TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            # Audit logs (enterprise)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    action TEXT NOT NULL,
                    resource_type TEXT,
                    resource_id TEXT,
                    ip_address TEXT,
                    user_agent TEXT,
                    details TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Events (persistent event history)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    priority INTEGER DEFAULT 3,
                    source TEXT,
                    data TEXT,
                    handled INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Subscriptions
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS subscriptions (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    tier TEXT NOT NULL,
                    status TEXT DEFAULT 'active',
                    started_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    expires_at TEXT,
                    payment_method TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            
            logger.info("Database initialized at %s", self.db_path)
    
    def _hash_password(self, password: str) -> str:
        """Hash password with salt."""
        salt = secrets.token_hex(16)
        pwd_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return f"{salt}${pwd_hash.hex()}"
    
    def _log_audit(self, conn, user_id: str, action: str, resource_type: str = None, 
                   resource_id: str = None, details: Dict = None):
        """Log audit event."""
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details)
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, action, resource_type, resource_id, json.dumps(details or {})))
    
    def create_user(self, user_id: str, email: str, password: str = None, name: str = "", **kwargs) -> Dict:
        """Create a new user."""
        password_hash = self._hash_password(password) if password else None
        
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO users (id, email, password_hash, name, api_keys, preferences, active_model, subscription)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                user_id, 
                email, 
                password_hash, 
                name,
                json.dumps(kwargs.get('api_keys', {})),
                json.dumps(kwargs.get('preferences', {})),
                kwargs.get('active_model', 'ollama'),
                kwargs.get('subscription', 'free')
            ))
            self._log_audit(conn, user_id, 'user_created', 'user', user_id)
        
        return self.get_user(user_id)
    
    def get_user(self, user_id: str) -> Optional[Dict]:
        """Get user by ID."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            row = cursor.fetchone()
            if row:
                return dict(row)
        return None
    
    def get_user_by_email(self, email: str) -> Optional[Dict]:
        """Get user by email."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
            row = cursor.fetchone()
            if row:
                return dict(row)
        return None
    
    def verify_password(self, user_id: str, password: str) -> bool:
        """Verify user password."""
        user = self.get_user(user_id)
        if not user or not user.get('password_hash'):
            return False
        return self._hash_password(password) == user['password_hash']
    
    def update_user(self, user_id: str, **kwargs) -> Dict:
        """Update user fields."""
        allowed = ['name', 'email', 'preferences', 'active_model', 'subscription', 'api_keys', 'last_login']
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        
        if not updates:
            return self.get_user(user_id)
        
        if 'preferences' in updates:
            updates['preferences'] = json.dumps(updates['preferences'])
        if 'api_keys' in updates:
            updates['api_keys'] = json.dumps(updates['api_keys'])
        
        updates['updated_at'] = datetime.now().isoformat()
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(f"UPDATE users SET {set_clause} WHERE id = ?", 
                         list(updates.values()) + [user_id])
            self._log_audit(conn, user_id, 'user_updated', 'user', user_id)
        
        return self.get_user(user_id)
    
    # Conversation methods
    def create_conversation(self, user_id: str, title: str = "New Chat") -> Dict:
        """Create new conversation."""
        import uuid
        conv_id = uuid.uuid4().hex
        
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO conversations (id, user_id, title) VALUES (?, ?, ?)",
                         (conv_id, user_id, title))
        
        return self.get_conversation(conv_id)
    
    def get_conversation(self, conv_id: str) -> Optional[Dict]:
        """Get conversation."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM conversations WHERE id = ?", (conv_id,))
            row = cursor.fetchone()
            if row:
                return dict(row)
        return None
    
    def get_conversations(self, user_id: str, limit: int = 50) -> List[Dict]:
        """Get user's conversations."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT ?",
                         (user_id, limit))
            return [dict(row) for row in cursor.fetchall()]
    
    def add_message(self, conv_id: str, role: str, content: str, **kwargs) -> Dict:
        """Add message to conversation."""
        import uuid
        msg_id = uuid.uuid4().hex
        
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO messages (id, conversation_id, role, content, model_used, directive, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (msg_id, conv_id, role, content, 
                   kwargs.get('model_used'), 
                   kwargs.get('directive'),
                   json.dumps(kwargs.get('metadata', {}))))
            
            cursor.execute("UPDATE conversations SET message_count = message_count + 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                         (conv_id,))
        
        return {'id': msg_id, 'conversation_id': conv_id, 'role': role, 'content': content}
    
    def get_conversation_messages(self, conv_id: str, limit: int = 100) -> List[Dict]:
        """Get conversation messages."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC LIMIT ?",
                         (conv_id, limit))
            return [dict(row) for row in cursor.fetchall()]
    
    # Memory methods
    def set_working_memory(self, user_id: str, key: str, value: Any, ttl: int = 3600):
        """Set working memory (with TTL)."""
        expires = datetime.now() + timedelta(seconds=ttl)
        
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO memory_working (user_id, key, value, expires_at)
                VALUES (?, ?, ?, ?)
            """, (user_id, key, json.dumps(value), expires.isoformat()))
    
    def get_working_memory(self, user_id: str, key: str) -> Optional[Any]:
        """Get working memory."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT value FROM memory_working 
                WHERE user_id = ? AND key = ? AND (expires_at IS NULL OR expires_at > ?)
            """, (user_id, key, datetime.now().isoformat()))
            row = cursor.fetchone()
            if row:
                return json.loads(row['value'])
        return None
    
    def add_episodic_memory(self, user_id: str, event_type: str, summary: str, 
                          details: Dict = None, importance: float = 0.5):
        """Add episodic memory."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO memory_episodic (user_id, event_type, summary, details, importance)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, event_type, summary, json.dumps(details or {}), importance))
    
    def get_episodic_memories(self, user_id: str, limit: int = 100) -> List[Dict]:
        """Get episodic memories."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM memory_episodic WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
                         (user_id, limit))
            return [dict(row) for row in cursor.fetchall()]
    
    def add_semantic_memory(self, user_id: str, entity_type: str, entity_name: str,
                          knowledge: str, confidence: float = 0.5):
        """Add semantic memory."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO memory_semantic (user_id, entity_type, entity_name, knowledge, confidence)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, entity_type, entity_name, knowledge, confidence))
    
    def search_semantic_memory(self, user_id: str, query: str, limit: int = 10) -> List[Dict]:
        """Search semantic memory."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM memory_semantic 
                WHERE user_id = ? AND (entity_name LIKE ? OR knowledge LIKE ?)
                ORDER BY confidence DESC LIMIT ?
            """, (user_id, f"%{query}%", f"%{query}%", limit))
            return [dict(row) for row in cursor.fetchall()]
    
    # Agent methods
    def create_agent(self, user_id: str, name: str, role: str = None, **kwargs) -> Dict:
        """Create new agent."""
        import uuid
        agent_id = uuid.uuid4().hex
        
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO agents (id, user_id, name, role, personality, tools, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (agent_id, user_id, name, role, 
                   kwargs.get('personality'), 
                   json.dumps(kwargs.get('tools', [])),
                   'idle'))
        
        return self.get_agent(agent_id)
    
    def get_agent(self, agent_id: str) -> Optional[Dict]:
        """Get agent."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM agents WHERE id = ?", (agent_id,))
            row = cursor.fetchone()
            if row:
                return dict(row)
        return None
    
    def get_agents(self, user_id: str) -> List[Dict]:
        """Get user's agents."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM agents WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def update_agent(self, agent_id: str, **kwargs) -> Dict:
        """Update agent."""
        updates = {k: v for k, v in kwargs.items() if k in ['name', 'role', 'personality', 'tools', 'status', 'last_active']}
        
        if 'tools' in updates:
            updates['tools'] = json.dumps(updates['tools'])
        updates['updated_at'] = datetime.now().isoformat()
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute(f"UPDATE agents SET {set_clause} WHERE id = ?", 
                         list(updates.values()) + [agent_id])
        
        return self.get_agent(agent_id)
    
    # Audit methods
    def get_audit_logs(self, user_id: str = None, limit: int = 100) -> List[Dict]:
        """Get audit logs."""
        with self._get_conn() as conn:
            else:
                cursor.execute("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]
    
    # Event persistence
    def persist_event(self, event_type: str, priority: int = 3, source: str = None, data: Dict = None):
        """Persist event to database."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO events (event_type, priority, source, data)
                VALUES (?, ?, ?, ?)
            """, (event_type, priority, source, json.dumps(data or {})))
    
    def get_events(self, event_type: str = None, limit: int = 100) -> List[Dict]:
        """Get persisted events."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            if event_type:
                cursor.execute("SELECT * FROM events WHERE event_type = ? ORDER BY created_at DESC LIMIT ?",
                             (event_type, limit))
            else:
                cursor.execute("SELECT * FROM events ORDER BY created_at DESC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]
    
    def cleanup_expired_memory(self):
        """Clean up expired working memory."""
        with self._get_conn() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM memory_working WHERE expires_at < ?", (datetime.now().isoformat(),))
            deleted = cursor.rowcount
        if deleted > 0:
            logger.info("Cleaned up %d expired memory entries", deleted)
        return deleted


# Singleton instance
_db_instance = None

def get_db(db_path: str = None) -> Database:
    """Get database singleton."""
    global _db_instance
    if _db_instance is None:
        _db_instance = Database(db_path)
    return _db_instance

def init_db(db_path: str = None):
    """Initialize database."""
    global _db_instance
    _db_instance = Database(db_path)
    return _db_instance
