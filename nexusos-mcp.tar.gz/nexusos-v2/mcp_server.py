"""
NexusOS MCP Server - Model Context Protocol Implementation

Provides tools, resources, and prompts to AI clients.
"""

import json
import os
import sys
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import get_db
from tool_engine import get_tool_engine


class MCPTools:
    """MCP Tools capability."""
    
    def __init__(self, server):
        self.server = server
        self.list_changed = False
    
    def list(self) -> List[Dict]:
        """List all available tools."""
        tools = [
            {"name": "file_read", "description": "Read a file", "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}},
            {"name": "file_write", "description": "Write to a file", "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]}},
            {"name": "file_list", "description": "List directory contents", "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}}}},
            {"name": "process_run", "description": "Run a shell command", "inputSchema": {"type": "object", "properties": {"command": {"type": "string"}, "timeout": {"type": "number"}}, "required": ["command"]}},
            {"name": "http_get", "description": "HTTP GET request", "inputSchema": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}},
            {"name": "http_post", "description": "HTTP POST request", "inputSchema": {"type": "object", "properties": {"url": {"type": "string"}, "data": {"type": "object"}}}},
            {"name": "system_info", "description": "Get system info", "inputSchema": {"type": "object", "properties": {}}},
            {"name": "search_files", "description": "Search files by content", "inputSchema": {"type": "object", "properties": {"query": {"type": "string"}, "path": {"type": "string"}}, "required": ["query"]}},
        ]
        return tools
    
    def call(self, name: str, arguments: Dict) -> Dict:
        """Call a tool."""
        result = self.server.tool_engine.execute_tool(name, **arguments)
        return result.to_dict() if hasattr(result, 'to_dict') else {"result": str(result)}


class MCPResources:
    """MCP Resources capability."""
    
    def __init__(self, server):
        self.server = server
    
    def list(self) -> List[Dict]:
        """List available resources."""
        resources = [
            {"uri": "nexus://user/me", "name": "Current User", "mimeType": "application/json"},
            {"uri": "nexus://memories/episodic", "name": "Episodic Memories", "mimeType": "application/json"},
            {"uri": "nexus://memories/semantic", "name": "Semantic Memories", "mimeType": "application/json"},
            {"uri": "nexus://conversations", "name": "Recent Conversations", "mimeType": "application/json"},
            {"uri": "nexus://agents", "name": "Available Agents", "mimeType": "application/json"},
        ]
        return resources
    
    def read(self, uri: str) -> str:
        """Read a resource."""
        parts = uri.replace("nexus://", "").split("/")
        
        if parts[0] == "memories" and len(parts) > 1:
            memory_type = parts[1]
            if memory_type == "episodic" and self.server.user_id:
                memories = self.server.db.get_episodic_memories(self.server.user_id)
                return json.dumps(memories[:10])
            elif memory_type == "semantic":
                return json.dumps({"message": "Use search endpoint"})
        
        elif parts[0] == "conversations" and self.server.user_id:
            convs = self.server.db.get_conversations(self.server.user_id)
            return json.dumps(convs[:10])
        
        elif parts[0] == "agents" and self.server.user_id:
            from agent_pool import get_agent_pool
            pool = get_agent_pool()
            agents = pool.get_agents(self.server.user_id)
            return json.dumps([a.to_dict() for a in agents])
        
        return json.dumps({"error": "Resource not found"})


class MCPServer:
    """
    Main MCP Server for NexusOS.
    
    Implements the Model Context Protocol for AI tool use.
    """
    
    def __init__(self, user_id: str = None, db_path: str = None, workspace_dir: str = None):
        self.user_id = user_id
        self.db = get_db(db_path)
        self.tool_engine = get_tool_engine(workspace_dir)
        
        self.tools = MCPTools(self)
        self.resources = MCPResources(self)
        
        self.server_info = {
            "name": "NexusOS MCP Server",
            "version": "1.0.0",
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {"listChanged": True},
                "resources": {"subscribe": True, "listChanged": True},
                "prompts": {"listChanged": False}
            }
        }
    
    def handle_message(self, message: Dict) -> Dict:
        """Handle an MCP message."""
        method = message.get("method")
        msg_id = message.get("id")
        params = message.get("params", {})
        
        try:
            if method == "initialize":
                result = self.server_info
                
            elif method == "tools/list":
                result = {"tools": self.tools.list()}
                
            elif method == "tools/call":
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                result = self.tools.call(tool_name, arguments)
                
            elif method == "resources/list":
                result = {"resources": self.resources.list()}
                
            elif method == "resources/read":
                uri = params.get("uri")
                contents = [{"uri": uri, "mimeType": "application/json", "text": self.resources.read(uri)}]
                result = {"contents": contents}
                
            else:
                return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": f"Unknown method: {method}"}}
            
            return {"jsonrpc": "2.0", "i}            
            return {"jsonrpc": "2.0", "id": msg_id, "result": result}
            
        except Exception as e:
            return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32603, "message": str(e)}}


# Standalone MCP HTTP Server
from flask import Flask, request, jsonify

def create_mcp_server(user_id: str = None) -> Flask:
    """Create Flask app with MCP endpoints."""
    app = Flask(__name__)
    mcp = MCPServer(user_id)
    
    @app.route('/mcp', methods=['POST'])
    def mcp_endpoint():
        message = request.json or {}
        response = mcp.handle_message(message)
        return jsonify(response)
    
    @app.route('/mcp/tools', methods=['GET'])
    def list_tools():
        return jsonify({"tools": mcp.tools.list()})
    
    @app.route('/mcp/resources', methods=['GET'])
    def list_resources():
        return jsonify({"resources": mcp.resources.list()})
    
    @app.route('/mcp/initialize', methods=['POST'])
    def initialize():
        return jsonify(mcp.server_info)
    
    return app


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8081)
    parser.add_argument('--user-id')
    args = parser.parse_args()
    
    app = create_mcp_server(args.user_id)
    app.run(host='0.0.0.0', port=args.port)
